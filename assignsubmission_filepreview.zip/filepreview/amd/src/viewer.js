// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Moodle assignsubmission_filepreview AMD module.
 * Provides client-side document viewing (Office docx, pptx, xlsx, PDF, TXT)
 * and Inline Split-Screen Grading integration.
 *
 * @module     assignsubmission_filepreview/viewer
 * @copyright  2024 Ferdiyanto Deni Sanjaya
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define(['jquery', 'core/notification', 'core/str'], function($, Notification, Str) {
    'use strict';

    var assetBaseUrl = '';
    var strings = {};
    var loadedScripts = {};
    var activeViewer = null;

    /**
     * Format a string template with placeholder replacements.
     *
     * @param {string} template Template string with {$a}
     * @param {string} val Replacement value
     * @returns {string}
     */
    function formatStr(template, val) {
        if (!template) {
            return val || '';
        }
        return template.replace('{$a}', val);
    }

    /**
     * Dynamically load external JS script once.
     *
     * @param {string} src
     * @returns {Promise}
     */
    function loadScript(src) {
        if (loadedScripts[src]) {
            return loadedScripts[src];
        }

        var promise = new Promise(function(resolve, reject) {
            var script = document.createElement('script');
            script.type = 'text/javascript';
            script.src = src;
            script.async = true;
            script.onload = function() {
                resolve();
            };
            script.onerror = function() {
                var msg = formatStr(strings.error_loading_script || 'Failed to load script: {$a}', src);
                reject(new Error(msg));
            };
            document.head.appendChild(script);
        });

        loadedScripts[src] = promise;
        return promise;
    }

    /**
     * Ensure JSZip is loaded.
     */
    function ensureJSZip() {
        if (window.JSZip) {
            return Promise.resolve(window.JSZip);
        }
        return loadScript(assetBaseUrl + '/vendor/jszip.min.js').then(function() {
            return window.JSZip;
        });
    }

    /**
     * Ensure docx-preview is loaded.
     */
    function ensureDocxPreview() {
        return ensureJSZip().then(function() {
            if (window.docx) {
                return window.docx;
            }
            return loadScript(assetBaseUrl + '/vendor/docx-preview.min.js').then(function() {
                return window.docx;
            });
        });
    }

    /**
     * Ensure SheetJS (xlsx) is loaded.
     */
    function ensureXLSX() {
        if (window.XLSX) {
            return Promise.resolve(window.XLSX);
        }
        return loadScript(assetBaseUrl + '/vendor/xlsx.full.min.js').then(function() {
            return window.XLSX;
        });
    }

    /**
     * Ensure PPTX Viewer is loaded.
     */
    function ensurePPTX() {
        return ensureJSZip().then(function() {
            if (window.PPTXViewer) {
                return window.PPTXViewer;
            }
            return loadScript(assetBaseUrl + '/vendor/pptx-viewer.js').then(function() {
                return window.PPTXViewer;
            });
        });
    }

    /**
     * Ensure PDF.js is loaded.
     */
    function ensurePDF() {
        if (window.pdfjsLib) {
            return Promise.resolve(window.pdfjsLib);
        }
        return loadScript(assetBaseUrl + '/vendor/pdf.min.js').then(function() {
            if (window.pdfjsLib && !window.pdfjsLib.GlobalWorkerOptions.workerSrc) {
                window.pdfjsLib.GlobalWorkerOptions.workerSrc = assetBaseUrl + '/vendor/pdf.worker.min.js';
            }
            return window.pdfjsLib;
        });
    }

    /**
     * Document Viewer Object.
     */
    function ViewerInstance(containerEl, files, options) {
        this.container = $(containerEl);
        this.files = files || [];
        this.options = options || {};
        this.activeFileIndex = 0;
        this.currentZoom = 1.0;
        this.imageRotation = 0;
        this.init();
    }

    ViewerInstance.prototype.init = function() {
        this.renderShell();
        if (this.files.length > 0) {
            this.loadFile(0);
        }
    };

    ViewerInstance.prototype.renderShell = function() {
        var self = this;
        var html = '<div class="fp-viewer-container">' +
            '<div class="fp-viewer-toolbar">' +
                '<div class="fp-toolbar-group">' +
                    '<select class="fp-file-select" aria-label="' + (strings.select_file || 'Select file') + '">';

        self.files.forEach(function(f, idx) {
            html += '<option value="' + idx + '">' + escapeHtml(f.filename) + ' (' + f.filesize + ')</option>';
        });

        html +=     '</select>' +
                '</div>' +
                '<div class="fp-toolbar-group">' +
                    '<button type="button" class="fp-btn fp-btn-icon fp-zoom-out" title="' + (strings.zoom_out || 'Zoom Out') + '"><i class="fa fa-search-minus"></i></button>' +
                    '<span class="fp-zoom-text">100%</span>' +
                    '<button type="button" class="fp-btn fp-btn-icon fp-zoom-in" title="' + (strings.zoom_in || 'Zoom In') + '"><i class="fa fa-search-plus"></i></button>' +
                    '<button type="button" class="fp-btn fp-zoom-reset" title="' + (strings.zoom_reset || 'Reset') + '"><i class="fa fa-arrows-alt"></i></button>' +
                    '<button type="button" class="fp-btn fp-btn-icon fp-rotate-btn" title="' + (strings.rotate_cw || 'Rotate 90°') + '" style="display:none;"><i class="fa fa-repeat fa-rotate-right"></i></button>' +
                    '<a href="#" target="_blank" class="fp-btn fp-download-btn" title="' + (strings.download || 'Download') + '"><i class="fa fa-download mr-1 me-1"></i> ' + (strings.download || 'Download') + '</a>' +
                    '<button type="button" class="fp-btn fp-btn-icon fp-fs-btn" title="' + (strings.fullscreen || 'Fullscreen') + '"><i class="fa fa-expand"></i></button>' +
                '</div>' +
            '</div>' +
            '<div class="fp-viewer-viewport">' +
                '<div class="fp-viewer-content"></div>' +
            '</div>' +
            '<div class="fp-viewer-footer">' +
                '<span class="fp-copyright-text">Submission file previewer ver 1.0.7 developed by Ferdiyanto Deni Sanjaya (<a href="https://gridiyans.my.id" target="_blank" rel="noopener noreferrer">gridiyans.my.id</a>) &copy; 2026</span>' +
            '</div>' +
        '</div>';

        self.container.html(html);

        // Bind events
        self.container.find('.fp-file-select').on('change', function() {
            var idx = parseInt($(this).val(), 10);
            self.loadFile(idx);
        });

        self.container.find('.fp-zoom-in').on('click', function() {
            self.setZoom(self.currentZoom + 0.15);
        });

        self.container.find('.fp-zoom-out').on('click', function() {
            self.setZoom(self.currentZoom - 0.15);
        });

        self.container.find('.fp-zoom-reset').on('click', function() {
            self.setZoom(1.0);
        });

        self.container.find('.fp-rotate-btn').on('click', function() {
            self.imageRotation = (self.imageRotation + 90) % 360;
            self.updateImageTransform();
        });

        self.container.find('.fp-fs-btn').on('click', function() {
            var el = self.container[0];
            if (!document.fullscreenElement) {
                if (el.requestFullscreen) {
                    el.requestFullscreen();
                } else if (el.webkitRequestFullscreen) {
                    el.webkitRequestFullscreen();
                }
            } else {
                if (document.exitFullscreen) {
                    document.exitFullscreen();
                }
            }
        });
    };

    ViewerInstance.prototype.updateImageTransform = function() {
        var img = this.container.find('.fp-image-element');
        if (img.length > 0) {
            img.css('transform', 'rotate(' + this.imageRotation + 'deg)');
        }
    };

    ViewerInstance.prototype.setZoom = function(scale) {
        if (scale < 0.4) scale = 0.4;
        if (scale > 3.0) scale = 3.0;
        this.currentZoom = scale;
        this.container.find('.fp-zoom-text').text(Math.round(scale * 100) + '%');
        this.container.find('.fp-viewer-content').css({
            'transform': 'scale(' + scale + ')',
            'transform-origin': 'top center'
        });
    };

    ViewerInstance.prototype.loadFile = function(index) {
        var self = this;
        if (!self.files[index]) return;

        self.activeFileIndex = index;
        self.setZoom(1.0);
        self.imageRotation = 0;
        var file = self.files[index];
        var ext = (file.extension || '').toLowerCase();
        var isImg = file.is_image || ['png', 'jpg', 'jpeg', 'gif', 'svg', 'webp', 'bmp', 'ico', 'tif', 'tiff'].indexOf(ext) !== -1;

        if (isImg) {
            self.container.find('.fp-rotate-btn').show();
        } else {
            self.container.find('.fp-rotate-btn').hide();
        }

        // Update download button
        self.container.find('.fp-download-btn').attr('href', file.downloadurl || file.url);
        self.container.find('.fp-file-select').val(index);

        var viewport = self.container.find('.fp-viewer-viewport');
        var content = self.container.find('.fp-viewer-content');

        content.html('<div class="fp-loading-state"><div class="fp-spinner"></div><p>' + (strings.loading_doc || 'Loading document...') + '</p></div>');

        var ext = (file.extension || '').toLowerCase();

        // 1. PDF
        if (ext === 'pdf') {
            self.renderPDF(file.url, content);
        }
        // 2. Word (.docx, .doc)
        else if (ext === 'docx') {
            self.renderDocx(file.url, content);
        }
        // 3. Excel (.xlsx, .xls, .csv)
        else if (ext === 'xlsx' || ext === 'xls' || ext === 'csv') {
            self.renderExcel(file.url, content, ext);
        }
        // 4. PowerPoint (.pptx)
        else if (ext === 'pptx') {
            self.renderPPTX(file.url, content);
        }
        // 5. Plain text / code
        else if (file.is_text || ['txt', 'md', 'html', 'json', 'xml', 'log', 'py', 'java', 'sql', 'c', 'cpp', 'php'].indexOf(ext) !== -1) {
            self.renderText(file.url, content);
        }
        // 6. Image
        else if (file.is_image || ['png', 'jpg', 'jpeg', 'gif', 'svg', 'webp', 'bmp', 'ico', 'tif', 'tiff'].indexOf(ext) !== -1) {
            self.renderImage(file.url, content);
        }
        // 7. Unsupported fallback
        else {
            self.renderUnsupported(file, content);
        }
    };

    ViewerInstance.prototype.renderPDF = function(url, content) {
        var self = this;
        var file = (self.files && self.files[self.activeFileIndex]) || {};
        content.html('<div class="fp-loading-state"><div class="fp-spinner"></div><p>' + (strings.loading_pdf || 'Loading PDF document...') + '</p></div>');

        function fetchPDFBuffer(targetUrl) {
            return fetch(targetUrl, { credentials: 'include' })
                .then(function(res) {
                    if (!res.ok) {
                        throw new Error('HTTP ' + res.status);
                    }
                    return res.arrayBuffer();
                })
                .then(function(buffer) {
                    var bytes = new Uint8Array(buffer);
                    var headerStr = '';
                    for (var i = 0; i < Math.min(bytes.length, 8); i++) {
                        headerStr += String.fromCharCode(bytes[i]);
                    }

                    if (headerStr.indexOf('%PDF') === -1) {
                        var decoder = new TextDecoder('utf-8');
                        var snippet = decoder.decode(bytes.subarray(0, 300));
                        console.warn('Non-PDF response from:', targetUrl, snippet);
                        throw new Error(strings.invalid_pdf_response || 'The server response is not a valid PDF file.');
                    }

                    return { buffer: buffer, bytes: bytes };
                });
        }

        // Try primary URL, then retry with file.downloadurl if different
        fetchPDFBuffer(url)
            .catch(function(firstErr) {
                if (file.downloadurl && file.downloadurl !== url) {
                    console.info('Retrying PDF fetch using fallback downloadurl:', file.downloadurl);
                    return fetchPDFBuffer(file.downloadurl);
                }
                throw firstErr;
            })
            .then(function(result) {
                var bytes = result.bytes;
                var buffer = result.buffer;

                // 1. Primary renderer: Mozilla PDF.js on HTML5 canvas with isEvalSupported: false for security
                return ensurePDF().then(function(pdfjsLib) {
                    var loadingTask = pdfjsLib.getDocument({
                        data: bytes,
                        disableFontFace: false,
                        isEvalSupported: false
                    });
                    return loadingTask.promise;
                }).then(function(pdfDoc) {
                    content.empty();
                    var pdfContainer = $('<div class="fp-pdf-container"></div>');
                    content.append(pdfContainer);

                    self.pdfDoc = pdfDoc;
                    self.pdfContainer = pdfContainer;
                    self.renderPDFPages(pdfDoc, pdfContainer);
                }).catch(function(pdfJsErr) {
                    console.warn('PDF.js rendering fallback to native embed:', pdfJsErr);
                    // 2. Fallback: Clean Blob URL without URL fragment
                    var pdfBlob = new Blob([buffer], { type: 'application/pdf' });
                    var blobUrl = URL.createObjectURL(pdfBlob);
                    if (!self.objectUrls) {
                        self.objectUrls = [];
                    }
                    self.objectUrls.push(blobUrl);

                    content.empty();
                    var iframe = $('<iframe src="' + blobUrl + '" style="width:100%; height:100%; min-height:650px; border:none; background:#ffffff; border-radius:4px;" allowfullscreen></iframe>');
                    content.append(iframe);
                });
            })
            .catch(function(err) {
                console.error('PDF preview error:', err);
                var directUrl = file.downloadurl || file.url || url;
                var errMsg = formatStr(strings.error_loading_pdf || 'Failed to load PDF document: {$a}', escapeHtml(err.message));
                content.html(
                    '<div class="fp-error-state">' +
                        '<i class="fa fa-exclamation-triangle fa-2x text-warning mb-2"></i>' +
                        '<p>' + errMsg + '</p>' +
                        '<div class="mt-3">' +
                            '<a href="' + directUrl + '" target="_blank" class="btn btn-outline-primary btn-sm mr-2 me-2">' +
                                '<i class="fa fa-external-link"></i> ' + (strings.open_in_new_tab || 'Open in New Tab') +
                            '</a>' +
                            '<a href="' + directUrl + '" class="btn btn-primary btn-sm">' +
                                '<i class="fa fa-download"></i> ' + (strings.download || 'Download File') +
                            '</a>' +
                        '</div>' +
                    '</div>'
                );
            });
    };

    ViewerInstance.prototype.renderPDFPages = function(pdfDoc, container) {
        var numPages = pdfDoc.numPages;
        container.empty();

        for (var pageNum = 1; pageNum <= numPages; pageNum++) {
            (function(pNum) {
                var pageWrapper = $('<div class="fp-pdf-page-wrapper" id="fp-pdf-page-' + pNum + '"></div>');
                var canvas = document.createElement('canvas');
                canvas.className = 'fp-pdf-page-canvas';
                pageWrapper.append(canvas);

                var pageNumberBadge = $('<div class="fp-pdf-page-number">' + pNum + ' / ' + numPages + '</div>');
                pageWrapper.append(pageNumberBadge);

                container.append(pageWrapper);

                pdfDoc.getPage(pNum).then(function(page) {
                    var baseViewport = page.getViewport({ scale: 1.5 });
                    canvas.height = baseViewport.height;
                    canvas.width = baseViewport.width;

                    var ctx = canvas.getContext('2d');
                    var renderContext = {
                        canvasContext: ctx,
                        viewport: baseViewport
                    };
                    page.render(renderContext);
                }).catch(function(pageErr) {
                    console.error('Error rendering PDF page ' + pNum, pageErr);
                });
            })(pageNum);
        }
    };

    ViewerInstance.prototype.renderDocx = function(url, content) {
        ensureDocxPreview().then(function(docx) {
            return fetch(url, { credentials: 'include' }).then(function(res) {
                if (!res.ok) throw new Error('HTTP ' + res.status);
                return res.arrayBuffer();
            });
        }).then(function(buffer) {
            content.empty();
            var docxContainer = $('<div class="docx-render-wrapper"></div>')[0];
            content.append(docxContainer);
            return window.docx.renderAsync(buffer, docxContainer, null, {
                className: 'docx',
                inWrapper: true,
                ignoreWidth: false,
                ignoreHeight: false
            });
        }).catch(function(err) {
            var errMsg = formatStr(strings.error_loading_word || 'Failed to load Word document: {$a}', escapeHtml(err.message));
            content.html('<div class="fp-error-state"><i class="fa fa-exclamation-triangle fa-2x"></i><p>' + errMsg + '</p></div>');
        });
    };

    ViewerInstance.prototype.renderExcel = function(url, content, ext) {
        ensureXLSX().then(function(XLSX) {
            return fetch(url, { credentials: 'include' }).then(function(res) {
                if (!res.ok) throw new Error('HTTP ' + res.status);
                return res.arrayBuffer();
            });
        }).then(function(buffer) {
            content.empty();
            var wb = window.XLSX.read(new Uint8Array(buffer), { type: 'array' });
            var wrapper = $('<div class="xlsx-render-wrapper"></div>');
            var tabContainer = $('<div class="xlsx-sheet-tabs"></div>');
            var tableContainer = $('<div class="xlsx-table-container"></div>');

            wrapper.append(tabContainer).append(tableContainer);
            content.append(wrapper);

            wb.SheetNames.forEach(function(sheetName, idx) {
                var btn = $('<button type="button" class="xlsx-tab-btn ' + (idx === 0 ? 'active' : '') + '">' + escapeHtml(sheetName) + '</button>');
                btn.on('click', function() {
                    tabContainer.find('.xlsx-tab-btn').removeClass('active');
                    $(this).addClass('active');
                    renderSheet(sheetName);
                });
                tabContainer.append(btn);
            });

            function renderSheet(name) {
                var ws = wb.Sheets[name];
                var html = window.XLSX.utils.sheet_to_html(ws, { editable: false });
                tableContainer.html(html);
            }

            if (wb.SheetNames.length > 0) {
                renderSheet(wb.SheetNames[0]);
            }
        }).catch(function(err) {
            var errMsg = formatStr(strings.error_loading_excel || 'Failed to load Excel spreadsheet: {$a}', escapeHtml(err.message));
            content.html('<div class="fp-error-state"><i class="fa fa-exclamation-triangle fa-2x"></i><p>' + errMsg + '</p></div>');
        });
    };

    ViewerInstance.prototype.renderPPTX = function(url, content) {
        ensurePPTX().then(function() {
            return fetch(url, { credentials: 'include' }).then(function(res) {
                if (!res.ok) throw new Error('HTTP ' + res.status);
                return res.arrayBuffer();
            });
        }).then(function(buffer) {
            content.empty();
            var pptxDiv = $('<div style="width: 100%; height: 600px;"></div>')[0];
            content.append(pptxDiv);
            var viewer = new window.PPTXViewer(pptxDiv);
            return viewer.load(buffer);
        }).catch(function(err) {
            var errMsg = formatStr(strings.error_loading_pptx || 'Failed to load PowerPoint presentation: {$a}', escapeHtml(err.message));
            content.html('<div class="fp-error-state"><i class="fa fa-exclamation-triangle fa-2x"></i><p>' + errMsg + '</p></div>');
        });
    };

    ViewerInstance.prototype.renderText = function(url, content) {
        fetch(url, { credentials: 'include' }).then(function(res) {
            if (!res.ok) throw new Error('HTTP ' + res.status);
            return res.text();
        }).then(function(text) {
            content.empty();
            var textDiv = $('<div class="text-render-wrapper"></div>');
            textDiv.text(text);
            content.append(textDiv);
        }).catch(function(err) {
            var errMsg = formatStr(strings.error_loading_text || 'Failed to load text file: {$a}', escapeHtml(err.message));
            content.html('<div class="fp-error-state"><i class="fa fa-exclamation-triangle fa-2x"></i><p>' + errMsg + '</p></div>');
        });
    };

    ViewerInstance.prototype.renderImage = function(url, content) {
        var self = this;
        var file = (self.files && self.files[self.activeFileIndex]) || {};
        self.imageRotation = 0;
        self.updateImageTransform();

        content.html('<div class="fp-loading-state"><div class="fp-spinner"></div><p>' + (strings.loading_doc || 'Loading document...') + '</p></div>');

        var wrapper = $('<div class="fp-image-container"></div>');
        var img = $('<img class="fp-image-element" alt="' + escapeHtml(file.filename || 'Image') + '" />');

        img.on('load', function() {
            content.empty().append(wrapper.append(img));
        });

        img.on('error', function() {
            var errMsg = formatStr(strings.error_loading_image || 'Failed to load image: {$a}', escapeHtml(file.filename || ''));
            var errHtml = '<div class="fp-error-state">' +
                '<i class="fa fa-file-image-o fa-3x mb-2 text-warning"></i>' +
                '<p>' + errMsg + '</p>' +
                '<a href="' + (file.downloadurl || url) + '" class="btn btn-primary mt-2">' +
                    '<i class="fa fa-download mr-1 me-1"></i> ' + (strings.download || 'Download File') +
                '</a>' +
            '</div>';
            content.html(errHtml);
        });

        img.attr('src', url);
    };

    ViewerInstance.prototype.renderUnsupported = function(file, content) {
        var html = '<div class="fp-error-state">' +
            '<i class="fa fa-file-o fa-3x mb-2"></i>' +
            '<h5>' + escapeHtml(file.filename) + '</h5>' +
            '<p class="text-muted">' + (strings.unsupported_format || 'Direct preview is not available for this file type. Please click Download to view it.') + '</p>' +
            '<a href="' + (file.downloadurl || file.url) + '" class="btn btn-primary mt-2">' +
                '<i class="fa fa-download mr-1 me-1"></i> ' + (strings.download || 'Download File') +
            '</a>' +
        '</div>';
        content.html(html);
    };

    function escapeHtml(text) {
        if (!text) return '';
        return String(text).replace(/[&<>"']/g, function(m) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[m];
        });
    }

    /**
     * Launch Full-Screen Split Workspace Overlay.
     */
    function openSplitWorkspace(files, graderUrl, studentName) {
        $('.fp-split-workspace-overlay').remove();

        var overlay = $('<div class="fp-split-workspace-overlay">' +
            '<div class="fp-split-header">' +
                '<h5 class="fp-split-title">' +
                    '<i class="fa fa-columns text-info"></i> ' +
                    '<span>' + (strings.split_screen || 'Split Screen Grader') + '</span>' +
                    (studentName ? ' - <span class="text-light">' + escapeHtml(studentName) + '</span>' : '') +
                '</h5>' +
                '<div class="fp-split-actions">' +
                    '<button type="button" class="fp-split-btn-close" title="' + (strings.close || 'Close') + '">' +
                        '<i class="fa fa-times"></i>' +
                    '</button>' +
                '</div>' +
            '</div>' +
            '<div class="fp-split-body">' +
                '<div class="fp-split-viewer-pane"></div>' +
                '<div class="fp-split-grading-pane">' +
                    '<div class="fp-grading-pane-header">' +
                        '<span><i class="fa fa-pencil-square-o mr-1 me-1"></i> ' + (strings.grade_panel_heading || 'Grade & Feedback') + '</span>' +
                    '</div>' +
                    '<iframe class="fp-grading-iframe" src="' + graderUrl + '"></iframe>' +
                '</div>' +
            '</div>' +
        '</div>');

        $('body').append(overlay);
        $('body').css('overflow', 'hidden');

        overlay.find('.fp-split-btn-close').on('click', function() {
            overlay.remove();
            $('body').css('overflow', '');
        });

        // Initialize viewer in left pane
        new ViewerInstance(overlay.find('.fp-split-viewer-pane'), files);
    }

    /**
     * Check if running in Moodle native Grader interface (action=grader).
     */
    function attachToMoodleGrader() {
        var reviewPanel = $('[data-region="review-panel-content"], [data-region="review-panel"]');
        if (reviewPanel.length === 0) {
            return false;
        }

        var files = [];

        // 1. Check if there are preview items from our plugin
        var summaryItem = $('.assignsubmission-filepreview-summary, .assignsubmission-filepreview-view');
        if (summaryItem.length > 0) {
            var btn = summaryItem.find('.filepreview-open-btn').first();
            var filesJson = btn.attr('data-files');
            if (filesJson) {
                try {
                    files = JSON.parse(filesJson);
                } catch (e) {}
            }
        }

        // 2. If no files from our plugin, extract from standard submission links in grading panel
        if (!files || files.length === 0) {
            $('[data-region="grade-panel"] .fileuploadsubmission a, [data-region="grade-panel"] .assignsubmission_file a, .assignsubmission_file a, .fileuploadsubmission a').each(function() {
                var a = $(this);
                // Skip icons without text
                if (a.find('img').length > 0 && !a.clone().children().remove().end().text().trim()) {
                    return;
                }
                var hr = a.attr('href') || '';
                if (hr.indexOf('/theme/image.php') !== -1 || hr.indexOf('/pix/') !== -1) {
                    return;
                }
                var fn = a.text().trim();
                if (!fn) {
                    return;
                }
                var extMatch = fn.match(/\.(pdf|docx|pptx|xlsx|xls|csv|txt|doc|ppt|png|jpg|jpeg|gif|svg|webp|bmp|ico|tif|tiff)$/i);
                if (extMatch) {
                    var streamUrl = hr;
                    files.push({
                        filename: fn,
                        url: streamUrl,
                        downloadurl: hr,
                        extension: extMatch[1].toLowerCase(),
                        filesize: ''
                    });
                }
            });
        }

        if (files && files.length > 0) {
            reviewPanel.empty();
            new ViewerInstance(reviewPanel, files);
            return true;
        }

        return false;
    }

    /**
     * Enhance standard Moodle file links (assignsubmission_file) on the page.
     * Allows teachers to preview files from older assignments without re-uploading!
     */
    function enhanceStandardFileLinks() {
        $('.assignsubmission_file a, .fileuploadsubmission a, td.c4 a, td.c5 a').each(function() {
            var a = $(this);
            if (a.hasClass('fp-enhanced') || a.closest('.assignsubmission-filepreview-summary').length > 0) {
                return;
            }
            // Skip icons without text
            if (a.find('img').length > 0 && !a.clone().children().remove().end().text().trim()) {
                return;
            }
            var href = a.attr('href') || '';
            if (href.indexOf('/theme/image.php') !== -1 || href.indexOf('/pix/') !== -1) {
                return;
            }
            var filename = a.text().trim();
            if (!filename) {
                return;
            }
            var extMatch = filename.match(/\.(pdf|docx|pptx|xlsx|xls|csv|txt|doc|ppt|png|jpg|jpeg|gif|svg|webp|bmp|ico|tif|tiff)$/i);
            if (extMatch) {
                a.addClass('fp-enhanced');
                var ext = extMatch[1].toLowerCase();
                var streamUrl = href;
                var btn = $('<button type="button" class="btn btn-sm btn-outline-primary py-0 px-1 ml-1 ms-1 fp-auto-preview-btn" title="' + (strings.preview || 'Preview') + '">' +
                    '<i class="fa fa-eye"></i> ' + (strings.preview || 'Preview') +
                '</button>');

                btn.on('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    var file = {
                        filename: filename,
                        url: streamUrl,
                        downloadurl: href,
                        extension: ext,
                        filesize: ''
                    };
                    openSplitWorkspace([file], window.location.href, filename);
                });

                a.after(btn);
            }
        });
    }

    return {
        init: function(config) {
            assetBaseUrl = config.assetbase || '';
            strings = config.strings || {};

            // 1. Try mounting to native Grader review panel
            attachToMoodleGrader();

            // 2. Enhance standard Moodle file links if present
            enhanceStandardFileLinks();

            // 3. Delegate click on "Preview & Grade" button
            $(document).off('click.fp', '[data-action="open-preview"]').on('click.fp', '[data-action="open-preview"]', function(e) {
                e.preventDefault();
                var btn = $(this);
                var container = btn.closest('.assignsubmission-filepreview-summary, .assignsubmission-filepreview-view');
                var filesJson = btn.attr('data-files');
                var files = [];

                if (filesJson) {
                    try {
                        files = JSON.parse(filesJson);
                    } catch (err) {}
                }

                // If not in data attribute, extract from DOM list
                if (files.length === 0) {
                    container.find('.filepreview-quick-view').each(function() {
                        var el = $(this);
                        files.push({
                            filename: el.data('filename'),
                            url: el.data('fileurl'),
                            downloadurl: el.data('downloadurl'),
                            extension: el.data('ext'),
                            filesize: el.siblings('.text-muted').text().replace(/[()]/g, '')
                        });
                    });
                }

                var graderUrl = btn.data('graderurl') || window.location.href;
                var studentName = container.closest('tr').find('.cell.c1, .cell.c2').text().trim();

                openSplitWorkspace(files, graderUrl, studentName);
            });

            // 4. Delegate click on quick view single file
            $(document).off('click.fp', '[data-action="quick-preview"]').on('click.fp', '[data-action="quick-preview"]', function(e) {
                e.preventDefault();
                var link = $(this);
                var file = {
                    filename: link.data('filename'),
                    url: link.data('fileurl'),
                    downloadurl: link.data('downloadurl'),
                    extension: link.data('ext'),
                    filesize: ''
                };
                openSplitWorkspace([file], window.location.href, '');
            });
        }
    };
});
